package Ejercicio;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ContainerRect contenedor = new ContainerRect(5);

        Rectangulo r1 = new Rectangulo(new Coordenada(1.5, 0.3), new Coordenada(7.6, 2.2));
        Rectangulo r2 = new Rectangulo(new Coordenada(4.0, 4.2), new Coordenada(9.4, -2.5));
        Rectangulo r3 = new Rectangulo(new Coordenada(2.1, 3.3), new Coordenada(5.7, 1.1));

        contenedor.addRectangulo(r1);
        contenedor.addRectangulo(r2);
        contenedor.addRectangulo(r3);

        System.out.println(contenedor);
    }
}