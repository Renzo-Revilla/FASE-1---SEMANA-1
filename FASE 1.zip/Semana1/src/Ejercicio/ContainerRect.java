package Ejercicio;


public class ContainerRect {
    private Rectangulo[] rectangulos;
    private double[] distancias;
    private double[] areas;
    private int n;
    private static int numRec = 0;

    public ContainerRect(int capacidad) {
        this.n = capacidad;
        this.rectangulos = new Rectangulo[n];
        this.distancias = new double[n];
        this.areas = new double[n];
    }

    public void addRectangulo(Rectangulo rect) {
        if (numRec < n) {
            rectangulos[numRec] = rect;
            distancias[numRec] = rect.calcularDistancia();
            areas[numRec] = rect.calcularArea();
            numRec++;
        } else {
            System.out.println("No se pueden agregar más rectángulos, capacidad llena.");
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Rectángulo | Coordenadas | Distancia | Área\n");
        for (int i = 0; i < numRec; i++) {
            sb.append((i + 1) + " | " + rectangulos[i] + " | " + distancias[i] + " | " + areas[i] + "\n");
        }
        return sb.toString();
    }
}