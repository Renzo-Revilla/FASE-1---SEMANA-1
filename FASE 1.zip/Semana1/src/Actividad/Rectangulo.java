package Actividad;

public class Rectangulo {
    private Coordenada esquina1;
    private Coordenada esquina2;

    public Rectangulo(Coordenada c1, Coordenada c2) {
        setEsquina1(c1);
        setEsquina2(c2);
    }

    public Coordenada getEsquina1() {
        return this.esquina1;
    }

    public void setEsquina1(Coordenada coo) {
        this.esquina1 = coo;
    }

    public Coordenada getEsquina2() {
        return this.esquina2;
    }

    public void setEsquina2(Coordenada coo) {
        this.esquina2 = coo;
    }

    public double calculoArea() {
        double base = Math.abs(esquina2.getX() - esquina1.getX());
        double altura = Math.abs(esquina2.getY() - esquina1.getY());
        return base * altura;
    }

    @Override
    public String toString() {
        return "Rectangulo [Esquina1: " + esquina1.toString() + ", Esquina2: " + esquina2.toString() + "]";
    }
}
