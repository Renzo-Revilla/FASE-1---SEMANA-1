package Actividad;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese coordenadas de la primera esquina del Rectángulo A (x1 y1):");
        double x1 = scanner.nextDouble();
        double y1 = scanner.nextDouble();
        System.out.println("Ingrese coordenadas de la segunda esquina del Rectángulo A (x2 y2):");
        double x2 = scanner.nextDouble();
        double y2 = scanner.nextDouble();

        Rectangulo A = new Rectangulo(new Coordenada(x1, y1), new Coordenada(x2, y2));

        System.out.println("Ingrese coordenadas de la primera esquina del Rectángulo B (x1 y1):");
        double x3 = scanner.nextDouble();
        double y3 = scanner.nextDouble();
        System.out.println("Ingrese coordenadas de la segunda esquina del Rectángulo B (x2 y2):");
        double x4 = scanner.nextDouble();
        double y4 = scanner.nextDouble();

        Rectangulo B = new Rectangulo(new Coordenada(x3, y3), new Coordenada(x4, y4));

        mostrarRectangulo(A, "A");
        mostrarRectangulo(B, "B");

        if (Verificador.esSobrePos(A, B)) {
            System.out.println("Caso 1: Los rectángulos A y B se sobreponen.");
            Rectangulo sobreposicion = rectanguloSobre(A, B);
            System.out.println("Área de sobreposición: " + sobreposicion.calculoArea());
        } else if (Verificador.esJunto(A, B)) {
            System.out.println("Caso 2: Los rectángulos A y B están juntos.");
        } else {
            System.out.println("Caso 3: Los rectángulos A y B son disjuntos.");
        }

        scanner.close();
    }

    public static void mostrarRectangulo(Rectangulo r, String nombre) {
        System.out.println("Rectángulo " + nombre + ": " + r.toString());
    }

    public static Rectangulo rectanguloSobre(Rectangulo r1, Rectangulo r2) {
        double xMin = Math.max(r1.getEsquina1().getX(), r2.getEsquina1().getX());
        double yMin = Math.max(r1.getEsquina1().getY(), r2.getEsquina1().getY());
        double xMax = Math.min(r1.getEsquina2().getX(), r2.getEsquina2().getX());
        double yMax = Math.min(r1.getEsquina2().getY(), r2.getEsquina2().getY());

        return new Rectangulo(new Coordenada(xMin, yMin), new Coordenada(xMax, yMax));
    }
}
